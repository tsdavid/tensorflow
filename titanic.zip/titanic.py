import tensorflow as tf
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

train = pd.read_csv("test.csv")
answear = pd.read_csv("gender_submission.csv")

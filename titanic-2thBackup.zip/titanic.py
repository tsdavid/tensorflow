
#타이타닉
import numpy as np
import tensorflow as tf
xy = np.loadtxt('train.csv' , delimiter=',' , dtype=np.float32)
x_data = xy[:,1:]
y_data = xy[:,0]

#placeholders for a tensor that will be always fed.
X = tf.placeholder(tf.float32 , shape=[None , 8])
Y = tf.placeholder(tf.float32 , shape=[None , 1])

W = tf.Variable(tf.random_normal([8,1]) , name="Weight")
b = tf.Variable(tf.random_normal([1]) , name="bias")

#Hyppthesis using sigmoid
hypothosis = tf.sigmoid(tf.matmul(X,W)+b)
#cost/loss function
cost = -tf.reduce_mean(Y*tf.log(hypothosis) + (1-Y)*tf.log(1-hypothosis))
train = tf.train.GradientDescentOptimizer(learning_rate=0.01).minimize(cost)

#Accuracy computation
predicted = tf.cast(hypothosis > 0.5 ,dtype = tf.float32)
accuracy = tf.reduce_mean(tf.cast(tf.equal(predicted , Y) ,dtype=tf.float32))
# Launch graph
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())

    for step in range(10001):
        sess.run(train, feed_dict={X:x_data,Y:y_data})
        if step % 400 == 0:
            print(step, sess.run(cost, feed_dict={X:x_data,Y:y_data}))

    # Accuracy report
    h, c, a = sess.run([hypothosis, predicted, accuracy], feed_dict={X:x_data,Y:y_data})
    print("\n:Hypothesis :", h, "\nCorrect: " ,c, "\nAccuracy: " , a )
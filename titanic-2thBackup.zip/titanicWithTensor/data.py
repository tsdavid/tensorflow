import pandas as pd
import numpy as np
train = pd.read_csv('C:/Users/user/PycharmProjects/tensorflow/titanic/train.csv')
test = pd.read_csv('C:/Users/user/PycharmProjects/tensorflow/titanic/test.csv')
answear = pd.read_csv('C:/Users/user/PycharmProjects/tensorflow/titanic/gender_submission.csv')

train = train.drop(['Cabin'], axis=1)
train = train.drop(['Ticket'], axis=1)
test  = test.drop(['Cabin'], axis=1)
test  = test.drop(['Ticket'] , axis=1)


train = train.fillna({"Embarked":"S"})

embarked_mapping = {"S":1 , "C":2 , "Q":3}
train['Embarked'] = train['Embarked'].map(embarked_mapping)
test['Embarked'] = test['Embarked'].map(embarked_mapping)

combine = [train, test]
for dataset in combine:
    dataset['Title'] = dataset.Name.str.extract('([A-Za-z]+)\.', expand=False)

pd.crosstab(train['Title'], train['Sex'])

for dataset in combine:
    dataset['Title'] = dataset['Title'].replace(['Capt', 'Col',
                                                 'Don', 'Dr', 'Major', 'Rev', 'Jonkheer',
                                                 'Dona'], 'Rare')
    dataset['Title'] = dataset['Title'].replace(['Countess', 'Lady', 'Sir'], 'Royal')
    dataset['Title'] = dataset['Title'].replace('Mlle', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Ms', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Mme', 'Mrs')

train[['Title', 'Survived']].groupby(['Title'], as_index=False).mean()

title_mapping = {'Mr': 1, 'Miss': 2, 'Mrs': 3, 'Master': 4, 'Royal': 5, 'Rare': 6}

for dataset in combine:
    dataset['Title'] = dataset['Title'].map(title_mapping)
    dataset['Title'] = dataset['Title'].fillna(0)


train = train.drop(['Name' , 'PassengerId'] , axis=1)
test = test.drop(['Name'] , axis=1)
combine = [train , test]

sex_mapping = {'male':0 , 'female':1}
for dataset in combine:
    dataset['Sex'] = dataset['Sex'].map(sex_mapping)
#train.head()

train['Age'] = train['Age'].fillna(-0.5)
test['Age'] = test['Age'].fillna(-0.5)
bins = [-1,0,5,12,18,24,35,60,np.inf]
labels = ['Unknown','Baby','Child','Teenager','Student','Young Adult','Adult','Senior']
train['AgeGroup'] = pd.cut(train['Age'], bins , labels = labels)
test['AgeGroup'] = pd.cut(test['Age'] ,bins,labels = labels)

age_mapping = {'Unknown':9,'Baby':1,'Child':2,'Teenager':3,'Student':4,'Young Adult':5,
               'Adult':6,'Senior':7}
train['AgeGroup'] = train['AgeGroup'].map(age_mapping)
test['AgeGroup'] = test['AgeGroup'].map(age_mapping)

train = train.drop(['Age'] , axis=1)
test = test.drop(['Age'],axis=1)

test['Fare'] = test['Fare'].fillna("14.4542")

test['Fare'] = test['Fare'].astype(np.float64)
test['Fare'].dtype

train['FareBand'] = pd.qcut(train['Fare'] , 4 , labels = [1,2,3,4])
test['FareBand'] = pd.qcut(test['Fare'] , 4 , labels = [1,2,3,4])

train = train.drop(['Fare'] , axis = 1)
test = test.drop(['Fare'] , axis = 1)

#pd.set_option('display.height', 1000)
pd.set_option('display.max_rows', 500)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)
test


#만들어진 파일을 csv로 뺴내자

#train.to_csv("C:/Users/user/Desktop",header=False,index=False)

